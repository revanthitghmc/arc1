# ARC Overseas Educational Consultants

Deployed using Next.js and Tailwind CSS

Run locally with:
```bash
npm install
npm run dev
```